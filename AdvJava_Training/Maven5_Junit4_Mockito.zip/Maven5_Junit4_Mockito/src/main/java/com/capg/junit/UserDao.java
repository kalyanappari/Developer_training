package com.capg.junit;

public interface UserDao {
	String findUsernameById(int id);
}
