package com.capg.assessment.services;

public interface ReportService {
	String getEmployeePerformance(Long employeeId);
}
