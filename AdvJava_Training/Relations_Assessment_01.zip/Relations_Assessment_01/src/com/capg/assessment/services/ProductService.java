package com.capg.assessment.services;

import com.capg.assessment.entities.Product;

public interface ProductService {
	 Product addProduct(String name, double price);
}
