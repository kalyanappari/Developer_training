package com.capg.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb16SpringBootJpaMovieCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
